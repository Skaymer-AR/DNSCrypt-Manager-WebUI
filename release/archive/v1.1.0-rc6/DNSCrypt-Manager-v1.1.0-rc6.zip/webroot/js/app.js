/* DNSCrypt Manager - app.js
 * Creado por Skaymer AR
 * Controlador principal de la WebUI. Sin frameworks, sin dependencias.
 *
 * ALCANCE DE ESTA WEBUI (pasada "minima funcional"):
 *   Incluye: Panel principal, Servidores (preestablecidos + NextDNS),
 *   Redireccion (aplicar/quitar, inicio automatico, modo IPv6),
 *   Diagnostico basico (Private DNS), Logs, Emergencia.
 *   Deferido a una proxima pasada (no incluido todavia): editor TOML
 *   avanzado en el navegador, gestor visual de copias de seguridad,
 *   seccion Aplicaciones (incluir/excluir por UID) y listas de bloqueo
 *   personalizadas. Todo eso ya es operable por CLI (ver
 *   `dnscrypt-manager help`) mientras se agrega su contraparte visual.
 */
'use strict';

/* Estructura minima para traduccion futura: un solo objeto con los textos
 * que arma el propio JS (los textos estaticos del HTML se traducen aparte,
 * el dia que se agregue selector de idioma). */
const STR = {
  running: 'Corriendo', stopped: 'Detenido',
  listeningYes: 'Escuchando', listeningNo: 'Sin escuchar',
  redirectOn: 'Activa', redirectOff: 'Inactiva',
  disabledBanner: 'Modulo DESHABILITADO (modo seguro). Toca "Habilitar" para reactivarlo.',
  noKsu: 'Esta WebUI necesita KernelSU, KernelSU Next o APatch. ' +
         'En Magisk no hay WebUI nativa: usa el boton de Accion del modulo ' +
         'o la CLI (su -c dnscrypt-manager help).',
  confirmRedirectApply: 'Esto va a redirigir el DNS del sistema hacia dnscrypt-proxy. ¿Continuar?',
  confirmRedirectRemove: '¿Quitar la redireccion DNS? El trafico volvera al DNS normal del sistema.',
  confirmPanic: 'PANIC va a detener todo, quitar la redireccion, restaurar tu DNS normal y ' +
                'DESHABILITAR el modulo hasta que lo reactives. ¿Continuar?',
  confirmLogsClear: '¿Borrar todos los logs? Esta accion no se puede deshacer.',
  timeout: 'Tiempo de espera agotado. Reintenta en unos segundos.'
};

let POLL_MS = 4000;
let pollTimer = null;
let busy = false; // evita acciones superpuestas mientras hay una en curso

/* --------------------------- utilidades DOM --------------------------- */
const $ = (id) => document.getElementById(id);

function setText(id, text) {
  const el = $(id);
  if (el) el.textContent = text;
}

function setDot(id, level) {
  // level: 'green' | 'amber' | 'red'
  const el = $(id);
  if (!el) return;
  el.classList.remove('dot-green', 'dot-amber', 'dot-red');
  el.classList.add('dot-' + level);
}

function toast(msg, kind) {
  const el = $('toast');
  if (!el) return;
  el.textContent = msg;
  el.className = 'toast show' + (kind ? ' toast-' + kind : '');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => { el.className = 'toast'; }, 3800);
}

function setBusy(v) {
  busy = v;
  document.querySelectorAll('button').forEach((b) => { b.disabled = v; });
}

/* ------------------------------ estado -------------------------------- */
function renderStatus(s) {
  if (!s) return;

  setDot('statusDot', s.disabled ? 'red' : (s.running && s.listening ? 'green' : (s.running ? 'amber' : 'red')));
  setText('statusHeadline', s.disabled ? 'Deshabilitado' : (s.running ? STR.running : STR.stopped));

  setText('pidText', s.running ? String(s.pid) : '—');
  setText('listenText', s.listen || '—');
  setText('listeningText', s.listening ? STR.listeningYes : STR.listeningNo);
  setText('versionText', s.version || '—');
  setText('serverText', s.server || '—');
  setText('backendText', s.backend === 'none' ? 'ninguno detectado' : (s.backend || '—'));

  const redirActive = s.redirect === 'activa';
  setDot('redirectDot', redirActive ? 'green' : 'amber');
  setText('redirectText', redirActive ? STR.redirectOn : STR.redirectOff);

  const bootCb = $('bootRedirectToggle');
  if (bootCb && document.activeElement !== bootCb) bootCb.checked = (s.boot_redirect === 1 || s.boot_redirect === '1');

  const v6sel = $('ipv6ModeSelect');
  if (v6sel && document.activeElement !== v6sel) v6sel.value = s.ipv6_mode || 'redirect';

  const banner = $('disabledBanner');
  if (banner) banner.classList.toggle('hidden', !s.disabled);
  setText('disabledBannerText', STR.disabledBanner);

  const binWarn = $('binMissingBanner');
  if (binWarn) binWarn.classList.toggle('hidden', !!s.binary_present);
}

async function refreshStatus() {
  if (!DCM.available()) return;
  const r = await DCM.run('status');
  if (r.errno !== 0) {
    toast(r.stderr || STR.timeout, 'error');
    return;
  }
  try {
    renderStatus(JSON.parse(r.stdout));
  } catch (e) {
    // JSON parcial o de un binario "fake"/incompatible: no rompemos la UI.
    console.warn('status --json no parseable:', e, r.stdout);
  }
}

function startPolling() {
  stopPolling();
  refreshStatus();
  pollTimer = setInterval(refreshStatus, POLL_MS);
}
function stopPolling() {
  if (pollTimer) clearInterval(pollTimer);
  pollTimer = null;
}
document.addEventListener('visibilitychange', () => {
  if (document.hidden) stopPolling(); else startPolling();
});

/* ------------------------- acciones de servicio ------------------------ */
async function doSimple(action, okMsg) {
  if (busy) return;
  setBusy(true);
  try {
    const r = await DCM.run(action);
    if (r.errno === 0) { toast(okMsg, 'ok'); } else { toast((r.stderr || r.stdout || 'Fallo').trim(), 'error'); }
    await refreshStatus();
  } finally {
    setBusy(false);
  }
}

function wireServiceButtons() {
  const bStart = $('btnStart'); if (bStart) bStart.addEventListener('click', () => doSimple('start', 'Servicio iniciado.'));
  const bStop = $('btnStop'); if (bStop) bStop.addEventListener('click', () => doSimple('stop', 'Servicio detenido.'));
  const bRestart = $('btnRestart'); if (bRestart) bRestart.addEventListener('click', () => doSimple('restart', 'Servicio reiniciado.'));
  const bEnable = $('btnEnable');
  if (bEnable) bEnable.addEventListener('click', async () => {
    if (busy) return;
    setBusy(true);
    try {
      // Paso 1: sacar el flag 'disable'. Paso 2: arrancar el servicio.
      // (Antes este boton solo llamaba a 'start', que con el flag puesto
      // SIEMPRE fallaba con "DESHABILITADO"; nunca sacaba el flag.)
      const rEnable = await DCM.run('enable');
      if (rEnable.errno !== 0) {
        toast((rEnable.stderr || 'No se pudo habilitar el modulo.').trim(), 'error');
        return;
      }
      const rStart = await DCM.run('start');
      toast(rStart.errno === 0 ? 'Modulo habilitado y servicio iniciado.' : (rStart.stderr || 'Fallo al iniciar').trim(),
            rStart.errno === 0 ? 'ok' : 'error');
    } finally {
      await refreshStatus();
      setBusy(false);
    }
  });
}

/* ------------------------------ test DNS -------------------------------- */
function renderTestDnsOutput(text) {
  const box = $('testDnsOutput');
  if (!box) return;
  box.innerHTML = '';
  const lines = String(text || '').split('\n').filter((l) => l.trim().length);
  if (!lines.length) { box.textContent = '(sin salida)'; return; }
  for (const line of lines) {
    const row = document.createElement('div');
    row.className = 'diag-line';
    if (/^\[\d\/4\]/.test(line)) {
      row.classList.add(line.includes('OMITIDA') ? 'diag-warn' : 'diag-ok');
    } else if (/^FALLO|^RESULTADO: DNS OK/.test(line)) {
      row.classList.add(line.startsWith('FALLO') ? 'diag-fail' : 'diag-ok');
    }
    row.textContent = line;
    box.appendChild(row);
  }
}

function wireTestDns() {
  const btn = $('btnTestDns');
  if (!btn) return;
  btn.addEventListener('click', async () => {
    if (busy) return;
    setBusy(true);
    setText('testDnsOutput', 'Probando…');
    try {
      const r = await DCM.run('testDns');
      renderTestDnsOutput((r.stdout || '') + (r.stderr ? '\n' + r.stderr : ''));
      toast(r.errno === 0 ? 'Prueba de DNS OK.' : 'La prueba fallo; revisa el detalle.', r.errno === 0 ? 'ok' : 'error');
      await refreshStatus();
    } finally {
      setBusy(false);
    }
  });
}

/* ------------------------------ servidores ------------------------------ */
function wireProviders() {
  document.querySelectorAll('[data-provider]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      if (busy) return;
      setBusy(true);
      try {
        const r = await DCM.runProvider(btn.getAttribute('data-provider'));
        toast(r.errno === 0 ? 'Proveedor aplicado. Reinicia el servicio para usarlo.' : (r.stderr || 'Fallo').trim(),
              r.errno === 0 ? 'ok' : 'error');
        await refreshStatus();
      } finally {
        setBusy(false);
      }
    });
  });

  const idInput = $('nextdnsId');
  const idError = $('nextdnsError');
  const applyBtn = $('btnNextdnsApply');

  function validateLive() {
    if (!idInput) return;
    const v = DCMValidate.nextdnsId(idInput.value);
    idInput.classList.toggle('field-invalid', !v.ok && idInput.value.trim().length > 0);
    if (idError) idError.textContent = idInput.value.trim().length ? v.msg : '';
  }
  if (idInput) idInput.addEventListener('input', validateLive);

  if (applyBtn) applyBtn.addEventListener('click', async () => {
    if (busy || !idInput) return;
    const v = DCMValidate.nextdnsId(idInput.value);
    if (!v.ok) { validateLive(); toast(v.msg, 'error'); return; }
    setBusy(true);
    try {
      const r = await DCM.runNextdns(idInput.value.trim());
      toast(r.errno === 0 ? 'NextDNS configurado. Reinicia el servicio para usarlo.' : (r.stderr || 'Fallo').trim(),
            r.errno === 0 ? 'ok' : 'error');
      await refreshStatus();
    } finally {
      setBusy(false);
    }
  });
}

/* ------------------------------ redireccion ------------------------------ */
function wireRedirect() {
  const bApply = $('btnRedirectApply');
  if (bApply) bApply.addEventListener('click', async () => {
    if (busy) return;
    if (!confirm(STR.confirmRedirectApply)) return;
    setBusy(true);
    try {
      const r = await DCM.run('redirectApply');
      toast(r.errno === 0 ? 'Redireccion aplicada.' : (r.stderr || r.stdout || 'Fallo').trim(),
            r.errno === 0 ? 'ok' : 'error');
      await refreshStatus();
    } finally {
      setBusy(false);
    }
  });

  const bRemove = $('btnRedirectRemove');
  if (bRemove) bRemove.addEventListener('click', async () => {
    if (busy) return;
    if (!confirm(STR.confirmRedirectRemove)) return;
    setBusy(true);
    try {
      const r = await DCM.run('redirectRemove');
      toast(r.errno === 0 ? 'Redireccion retirada.' : (r.stderr || 'Fallo').trim(), r.errno === 0 ? 'ok' : 'error');
      await refreshStatus();
    } finally {
      setBusy(false);
    }
  });

  const bootCb = $('bootRedirectToggle');
  if (bootCb) bootCb.addEventListener('change', async (ev) => {
    if (busy) return;
    setBusy(true);
    try {
      const r = await DCM.run(ev.target.checked ? 'bootRedirOn' : 'bootRedirOff');
      if (r.errno !== 0) { ev.target.checked = !ev.target.checked; toast((r.stderr || 'Fallo').trim(), 'error'); }
      else { toast('Preferencia guardada.', 'ok'); }
    } finally {
      setBusy(false);
    }
  });

  const v6sel = $('ipv6ModeSelect');
  if (v6sel) v6sel.addEventListener('change', async (ev) => {
    if (busy) return;
    setBusy(true);
    try {
      const r = await DCM.runIpv6Mode(ev.target.value);
      toast(r.errno === 0 ? 'Modo IPv6 actualizado. Se aplica en el proximo "Aplicar redireccion".' : (r.stderr || 'Fallo').trim(),
            r.errno === 0 ? 'ok' : 'error');
    } finally {
      setBusy(false);
    }
  });
}

/* ------------------------------ private dns ------------------------------ */
function wirePrivateDns() {
  const btn = $('btnPrivateDns');
  if (!btn) return;
  btn.addEventListener('click', async () => {
    if (busy) return;
    setBusy(true);
    setText('privateDnsText', 'Consultando…');
    try {
      const r = await DCM.run('privateDns');
      setText('privateDnsText', (r.stdout || r.stderr || '(sin datos)').trim());
    } finally {
      setBusy(false);
    }
  });
}

/* -------------------------------- logs ---------------------------------- */
function wireLogs() {
  const bLogs = $('btnLogs');
  if (bLogs) bLogs.addEventListener('click', async () => {
    if (busy) return;
    setBusy(true);
    setText('logsOutput', 'Cargando…');
    try {
      const r = await DCM.run('logs');
      setText('logsOutput', (r.stdout || r.stderr || '(sin logs)').trim());
    } finally {
      setBusy(false);
    }
  });

  const bClear = $('btnLogsClear');
  if (bClear) bClear.addEventListener('click', async () => {
    if (busy) return;
    if (!confirm(STR.confirmLogsClear)) return;
    setBusy(true);
    try {
      const r = await DCM.run('logsClear');
      toast(r.errno === 0 ? 'Logs borrados.' : (r.stderr || 'Fallo').trim(), r.errno === 0 ? 'ok' : 'error');
      setText('logsOutput', '');
    } finally {
      setBusy(false);
    }
  });
}

/* ------------------------------ emergencia -------------------------------- */
function wirePanic() {
  const btn = $('btnPanic');
  if (!btn) return;
  btn.addEventListener('click', async () => {
    if (busy) return;
    if (!confirm(STR.confirmPanic)) return;
    setBusy(true);
    try {
      const r = await DCM.run('panic');
      toast(r.errno === 0 ? 'Modulo deshabilitado y red restaurada.' : (r.stderr || 'Fallo').trim(),
            r.errno === 0 ? 'ok' : 'error');
      await refreshStatus();
    } finally {
      setBusy(false);
    }
  });
}

/* ======================================================================== *
 *  SEGURIDAD v0.2.0 — proteccion, perfiles, listas, allowlist, excepciones,
 *  auditoria de fugas, eventos, privacidad. Todo textContent (sin innerHTML
 *  con datos); botones bloqueados via setBusy durante cada operacion.
 * ======================================================================== */
const SEC_STR = {
  catSub: {
    malware: 'Sitios que distribuyen software malicioso.',
    phishing: 'Paginas que roban credenciales haciendose pasar por otras.',
    scams: 'Dominios de estafas conocidas.',
    trackers: 'Rastreadores de actividad (puede afectar analitica).',
    ads: 'Publicidad (puede romper apps o paginas).',
    cryptomining: 'Mineria de criptomonedas en el navegador.'
  },
  confirmProfileStrict: 'El perfil Estricto activa fail-closed: si DNSCrypt deja de funcionar, ' +
    'podes quedarte sin DNS hasta restaurar la red (PANIC siempre la restaura). ¿Aplicar Estricto?',
  confirmEventsClear: '¿Borrar todo el historial de eventos bloqueados?',
  confirmAllowClear: '¿Vaciar la allowlist por completo?'
};

/* Muestra un error de backend concreto: comando + codigo + mensaje. */
function backendError(res, cmdLabel) {
  const msg = (res.stderr || res.stdout || '').trim() || 'sin detalle';
  return (cmdLabel ? cmdLabel + ': ' : '') + msg + ' (rc=' + res.errno + ')';
}

function safeParse(txt) {
  try { return JSON.parse(txt); } catch (_) { return null; }
}

/* ------------------------------ proteccion ------------------------------ */
async function refreshProtection() {
  const box = $('protectionList');
  if (!box) return;
  const r = await DCM.run('protectionStatus');
  if (r.errno !== 0) { setText('protectionList', backendError(r, 'protection status')); return; }
  const data = safeParse(r.stdout);
  if (!data) { setText('protectionList', 'Respuesta no valida del backend.'); return; }
  box.textContent = '';
  DCM.CATEGORIES.forEach((cat) => {
    const info = data[cat] || {};
    const row = document.createElement('div');
    row.className = 'toggle-row';
    const left = document.createElement('div');
    const name = document.createElement('div');
    name.className = 'tl-name'; name.textContent = cat;
    const sub = document.createElement('div');
    sub.className = 'tl-sub';
    const dom = (info.domains != null ? info.domains : 0);
    const st = info.status || 'sin_lista';
    sub.textContent = (SEC_STR.catSub[cat] || '') + ' · ' + dom + ' dominios (' + st + ')';
    left.appendChild(name); left.appendChild(sub);
    const lab = document.createElement('label');
    lab.className = 'switch';
    const cb = document.createElement('input');
    cb.type = 'checkbox'; cb.checked = !!info.enabled;
    cb.addEventListener('change', async () => {
      if (busy) return;
      setBusy(true);
      try {
        const rr = await DCM.runProtection(cat, cb.checked);
        if (rr.errno !== 0) { cb.checked = !cb.checked; toast(backendError(rr, 'protection'), 'error'); }
        else { toast('Proteccion ' + cat + (cb.checked ? ' activada.' : ' desactivada.'), 'ok'); }
        await refreshProtection();
      } finally { setBusy(false); }
    });
    lab.appendChild(cb);
    row.appendChild(left); row.appendChild(lab);
    box.appendChild(row);
  });
  setText('protectionTotal', 'Total activo: ' + (data.active_total != null ? data.active_total : 0) + ' dominios.');
}

/* ------------------------------- perfiles ------------------------------- */
async function refreshProfile() {
  const r = await DCM.run('profileStatus');
  if (r.errno === 0) {
    const d = safeParse(r.stdout);
    if (d && d.profile) setText('profileCurrent', d.profile);
  }
}
function wireProfiles() {
  document.querySelectorAll('[data-profile]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      if (busy) return;
      const prof = btn.getAttribute('data-profile');
      if (prof === 'strict' && !confirm(SEC_STR.confirmProfileStrict)) return;
      setBusy(true);
      setText('profilePlan', 'Aplicando perfil…');
      try {
        const action = prof === 'balanced' ? 'profileBalanced' : (prof === 'strict' ? 'profileStrict' : 'profilePrivacy');
        const r = await DCM.run(action);
        setText('profilePlan', (r.stdout || r.stderr || '').trim());
        toast(r.errno === 0 ? 'Perfil ' + prof + ' aplicado.' : backendError(r, 'perfil'), r.errno === 0 ? 'ok' : 'error');
        await Promise.all([refreshProfile(), refreshProtection(), refreshStatus()]);
      } finally { setBusy(false); }
    });
  });
}

/* -------------------------------- listas -------------------------------- */
function renderBlocklists(data) {
  const box = $('blocklistsTable');
  if (!box) return;
  box.textContent = '';
  if (!data) { box.textContent = 'Sin datos.'; return; }
  DCM.CATEGORIES.forEach((cat) => {
    const info = data[cat]; if (!info) return;
    const row = document.createElement('div');
    row.className = 'event-row';
    const t = document.createElement('div');
    t.textContent = cat + ' — ' + (info.enabled ? 'ON' : 'OFF') + ' · ' +
      (info.domains != null ? info.domains : 0) + ' dominios · ' + (info.status || 'sin_lista') +
      (info.updated ? ' · ' + info.updated : '');
    row.appendChild(t);
    if (info.enabled) {
      const acts = document.createElement('div');
      acts.className = 'event-actions';
      const up = document.createElement('button');
      up.textContent = 'Actualizar';
      up.addEventListener('click', async () => {
        if (busy) return; setBusy(true);
        try {
          const rr = await DCM.runBlocklistUpdateCat(cat);
          toast(rr.errno === 0 ? cat + ' actualizada.' : backendError(rr, 'update ' + cat), rr.errno === 0 ? 'ok' : 'error');
          await refreshBlocklists();
        } finally { setBusy(false); }
      });
      const rb = document.createElement('button');
      rb.textContent = 'Revertir';
      rb.addEventListener('click', async () => {
        if (busy) return; setBusy(true);
        try {
          const rr = await DCM.runBlocklistRollbackCat(cat);
          toast(rr.errno === 0 ? cat + ' revertida.' : backendError(rr, 'rollback ' + cat), rr.errno === 0 ? 'ok' : 'error');
          await refreshBlocklists();
        } finally { setBusy(false); }
      });
      acts.appendChild(up); acts.appendChild(rb);
      row.appendChild(acts);
    }
    box.appendChild(row);
  });
}
async function refreshBlocklists() {
  const r = await DCM.run('blocklistsStatus');
  if (r.errno !== 0) { setText('blocklistsTable', backendError(r, 'blocklists status')); return; }
  renderBlocklists(safeParse(r.stdout));
}
function wireBlocklists() {
  const up = $('btnBlocklistsUpdate');
  if (up) up.addEventListener('click', async () => {
    if (busy) return; setBusy(true);
    setText('blocklistsTable', 'Descargando y verificando…');
    try {
      const r = await DCM.run('blocklistsUpdate');
      toast(r.errno === 0 ? 'Listas actualizadas.' : backendError(r, 'update'), r.errno === 0 ? 'ok' : 'error');
      await refreshBlocklists();
      await refreshProtection();
    } finally { setBusy(false); }
  });
  const val = $('btnBlocklistsValidate');
  if (val) val.addEventListener('click', async () => {
    if (busy) return; setBusy(true);
    try {
      const r = await DCM.run('blocklistsValidate');
      setText('blocklistsTable', (r.stdout || r.stderr || '').trim());
      toast(r.errno === 0 ? 'Validacion OK.' : 'Hay listas con problemas.', r.errno === 0 ? 'ok' : 'error');
    } finally { setBusy(false); }
  });
}

/* ------------------------------ allowlist ------------------------------- */
async function refreshAllowlist() {
  const r = await DCM.run('allowlistList');
  if (r.errno !== 0) { setText('allowList', backendError(r, 'allowlist list')); return; }
  const d = safeParse(r.stdout);
  if (!d) { setText('allowList', 'Sin datos.'); return; }
  const box = $('allowList');
  box.textContent = '';
  if (!d.domains || !d.domains.length) { box.textContent = '(allowlist vacia)'; return; }
  d.domains.forEach((dom) => {
    const row = document.createElement('div');
    row.className = 'event-row';
    const name = document.createElement('span');
    name.textContent = dom + '  ';
    const del = document.createElement('button');
    del.textContent = 'Quitar';
    del.className = 'small danger';
    del.addEventListener('click', async () => {
      if (busy) return; setBusy(true);
      try {
        const rr = await DCM.runAllowlistRemove(dom);
        toast(rr.errno === 0 ? 'Quitado: ' + dom : backendError(rr, 'remove'), rr.errno === 0 ? 'ok' : 'error');
        await refreshAllowlist();
      } finally { setBusy(false); }
    });
    row.appendChild(name); row.appendChild(del);
    box.appendChild(row);
  });
  setText('allowError', d.count + ' dominio(s) en la allowlist.');
}
function wireAllowlist() {
  const inp = $('allowInput');
  const err = $('allowError');
  function live() {
    if (!inp) return;
    if (!inp.value.trim().length) { if (err) err.textContent = ''; inp.classList.remove('field-invalid'); return; }
    const v = DCMValidate.isValidDomain(inp.value);
    inp.classList.toggle('field-invalid', !v.ok);
    if (err) err.textContent = v.ok ? '' : v.msg;
  }
  if (inp) inp.addEventListener('input', live);

  const add = $('btnAllowAdd');
  if (add) add.addEventListener('click', async () => {
    if (busy || !inp) return;
    const v = DCMValidate.isValidDomain(inp.value);
    if (!v.ok) { live(); toast(v.msg, 'error'); return; }
    setBusy(true);
    try {
      const r = await DCM.runAllowlistAdd(inp.value);
      if (r.errno === 0) { toast('Agregado.', 'ok'); inp.value = ''; await refreshAllowlist(); }
      else { toast(backendError(r, 'allowlist add'), 'error'); }
    } finally { setBusy(false); }
  });

  const search = $('btnAllowSearch');
  if (search) search.addEventListener('click', async () => {
    if (busy || !inp) return;
    setBusy(true);
    try {
      const r = await DCM.runAllowlistSearch(inp.value);
      const out = (r.stdout || '').trim();
      setText('allowList', out.length ? out : '(sin coincidencias)');
    } finally { setBusy(false); }
  });

  const imp = $('btnAllowImport');
  if (imp) imp.addEventListener('click', async () => {
    if (busy) return;
    const ta = $('allowImport');
    if (!ta) return;
    const lines = ta.value.split('\n').map((x) => x.trim().toLowerCase()).filter((x) => x.length && x[0] !== '#');
    if (!lines.length) { toast('No hay dominios para importar.', 'error'); return; }
    if (lines.length > 200) { toast('Maximo 200 dominios por importacion desde la WebUI.', 'error'); return; }
    setBusy(true);
    let added = 0, dup = 0, bad = 0;
    try {
      for (const dom of lines) {
        const v = DCMValidate.isValidDomain(dom);
        if (!v.ok) { bad++; continue; }
        const r = await DCM.runAllowlistAdd(dom);
        if (r.errno === 0) {
          if ((r.stdout || '').indexOf('Ya estaba') >= 0) dup++; else added++;
        } else { bad++; }
      }
      toast('Importado: +' + added + ', dup ' + dup + ', invalidos ' + bad + '.', bad ? 'error' : 'ok');
      ta.value = '';
      await refreshAllowlist();
    } finally { setBusy(false); }
  });

  const exp = $('btnAllowExport');
  if (exp) exp.addEventListener('click', async () => {
    if (busy) return; setBusy(true);
    try {
      const r = await DCM.run('allowlistList');
      const d = safeParse(r.stdout);
      const text = d && d.domains ? d.domains.join('\n') : '';
      toast('Allowlist (' + (d ? d.count : 0) + ') mostrada abajo para copiar.', 'ok');
      setText('allowList', text || '(vacia)');
    } finally { setBusy(false); }
  });
}

/* --------------------------- excepciones temp --------------------------- */
async function refreshTempAllow() {
  const r = await DCM.run('tempAllowList');
  if (r.errno !== 0) { setText('tempList', backendError(r, 'temporary-allow list')); return; }
  const d = safeParse(r.stdout);
  if (!d) { setText('tempList', 'Sin datos.'); return; }
  const box = $('tempList');
  box.textContent = '';
  if (!d.exceptions || !d.exceptions.length) { box.textContent = '(sin excepciones vigentes)'; return; }
  d.exceptions.forEach((ex) => {
    const row = document.createElement('div');
    row.className = 'event-row';
    const rem = (ex.remaining === 'boot') ? 'hasta reiniciar' : ('quedan ' + ex.remaining + 's');
    const t = document.createElement('div');
    t.textContent = ex.domain + ' — ' + rem + ' · ' + (ex.reason || '-');
    const acts = document.createElement('div');
    acts.className = 'event-actions';
    const rev = document.createElement('button');
    rev.textContent = 'Revocar'; rev.className = 'small danger';
    rev.addEventListener('click', async () => {
      if (busy) return; setBusy(true);
      try {
        const rr = await DCM.runTempAllowRemove(ex.domain);
        toast(rr.errno === 0 ? 'Revocada: ' + ex.domain : backendError(rr, 'revocar'), rr.errno === 0 ? 'ok' : 'error');
        await refreshTempAllow();
      } finally { setBusy(false); }
    });
    acts.appendChild(rev);
    row.appendChild(t); row.appendChild(acts);
    box.appendChild(row);
  });
}
function wireTempAllow() {
  const inp = $('tempInput');
  const err = $('tempError');
  function live() {
    if (!inp) return;
    if (!inp.value.trim().length) { if (err) err.textContent = ''; inp.classList.remove('field-invalid'); return; }
    const v = DCMValidate.isValidDomain(inp.value);
    inp.classList.toggle('field-invalid', !v.ok);
    if (err) err.textContent = v.ok ? '' : v.msg;
  }
  if (inp) inp.addEventListener('input', live);

  const add = $('btnTempAdd');
  if (add) add.addEventListener('click', async () => {
    if (busy || !inp) return;
    const v = DCMValidate.isValidDomain(inp.value);
    if (!v.ok) { live(); toast(v.msg, 'error'); return; }
    const dur = ($('tempDuration') || {}).value || '15m';
    const reason = (($('tempReason') || {}).value || '').trim();
    setBusy(true);
    try {
      const r = await DCM.runTempAllowAdd(inp.value, dur, reason);
      toast(r.errno === 0 ? 'Excepcion creada.' : backendError(r, 'excepcion'), r.errno === 0 ? 'ok' : 'error');
      if (r.errno === 0) { inp.value = ''; const rr = $('tempReason'); if (rr) rr.value = ''; }
      await Promise.all([refreshTempAllow(), refreshAllowlist()]);
    } finally { setBusy(false); }
  });
}

/* ---------------------------- auditoria fugas --------------------------- */
let lastLeakText = '';
async function runLeak() {
  const r = await DCM.run('leakTest');
  const box = $('leakResults');
  if (!box) return;
  if (r.errno !== 0) { setText('leakResults', backendError(r, 'leak-test')); return; }
  const d = safeParse(r.stdout);
  if (!d || !d.checks) { setText('leakResults', 'Respuesta no valida.'); return; }
  box.textContent = '';
  const lines = [];
  d.checks.forEach((c) => {
    const row = document.createElement('div');
    row.className = 'leak-row';
    const st = document.createElement('span');
    st.className = 'st-' + c.state;
    st.textContent = c.state;
    const nm = document.createElement('span');
    nm.textContent = c.name + ': ';
    const dt = document.createElement('div');
    dt.className = 'tl-sub'; dt.textContent = c.detail;
    row.appendChild(nm); row.appendChild(st); row.appendChild(dt);
    box.appendChild(row);
    lines.push(c.name + '\t' + c.state + '\t' + c.detail);
  });
  lastLeakText = lines.join('\n');
}
function wireLeak() {
  const btn = $('btnLeakTest');
  if (btn) btn.addEventListener('click', async () => {
    if (busy) return; setBusy(true);
    setText('leakResults', 'Auditando…');
    try { await runLeak(); } finally { setBusy(false); }
  });
  const cp = $('btnLeakCopy');
  if (cp) cp.addEventListener('click', async () => {
    if (!lastLeakText) { toast('Primero ejecuta la prueba.', 'error'); return; }
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) { await navigator.clipboard.writeText(lastLeakText); toast('Diagnostico copiado.', 'ok'); }
      else { toast('Copia manual: el detalle esta arriba.', 'ok'); }
    } catch (_) { toast('No se pudo copiar automaticamente.', 'error'); }
  });
}

/* -------------------------------- eventos ------------------------------- */
/* v1.0.0: carga DIFERIDA. Nada de esto corre en el arranque de la WebUI ni al
   entrar a Actividad: solo cuando el usuario expande el panel Eventos.
   Al cerrar se desmonta la lista del DOM y las respuestas tardias se ignoran
   (token de generacion). Se renderizan como maximo EV.page filas. */
var EV = { open: false, gen: 0, page: 20, shown: 20 };

async function refreshEvents() {
  if (!EV.open) return;                       // cerrado -> no se consulta nada
  const myGen = EV.gen;
  const r = await DCM.run('eventsList');
  if (myGen !== EV.gen || !EV.open) return;   // cerrado mientras cargaba -> ignorar
  const box = $('eventsList');
  if (!box) return;
  if (r.errno !== 0) { setText('eventsList', backendError(r, 'events list')); return; }
  const d = safeParse(r.stdout);
  if (!d) { setText('eventsList', 'Sin datos.'); return; }
  const filterEl = $('eventsFilter');
  const filter = filterEl ? filterEl.value.trim().toLowerCase() : '';
  box.textContent = '';
  const more = $('eventsMore'); if (more) more.textContent = '';
  let evs = d.events || [];
  if (filter) evs = evs.filter((e) => (e.domain || '').indexOf(filter) >= 0);
  if (!evs.length) { box.textContent = '(sin eventos)'; evSummary(0); return; }
  const total = evs.length;
  evSummary(total);
  const slice = evs.slice(0, EV.shown);
  if (total > slice.length && more) {         // paginacion: no cientos de filas juntas
    const b = document.createElement('button');
    b.className = 'small';
    b.textContent = I18N.t('ev.more') + ' (' + slice.length + '/' + total + ')';
    b.addEventListener('click', () => { if (busy) return; EV.shown += EV.page; refreshEvents(); });
    more.appendChild(b);
  }
  slice.forEach((e) => {
    const row = document.createElement('div');
    row.className = 'event-row';
    const head = document.createElement('div');
    head.textContent = (e.time || '') + '  ' + (e.domain || '');
    const meta = document.createElement('div');
    meta.className = 'tl-sub';
    meta.textContent = 'categoria: ' + (e.category || '-') + ' · regla: ' + (e.rule || '-') +
      (e.list ? ' · lista: ' + e.list : '') + (e.allowed_now ? ' · permitido ahora' : '');
    const acts = document.createElement('div');
    acts.className = 'event-actions';
    [['5m', 'Permitir 5m'], ['1h', 'Permitir 1h']].forEach(([dur, label]) => {
      const b = document.createElement('button');
      b.textContent = label;
      b.addEventListener('click', async () => {
        if (busy) return; setBusy(true);
        try {
          const rr = await DCM.runTempAllowAdd(e.domain, dur);
          toast(rr.errno === 0 ? label + ' → ' + e.domain : backendError(rr, 'permitir'), rr.errno === 0 ? 'ok' : 'error');
          await refreshTempAllow();
        } finally { setBusy(false); }
      });
      acts.appendChild(b);
    });
    const al = document.createElement('button');
    al.textContent = 'A la allowlist';
    al.addEventListener('click', async () => {
      if (busy) return; setBusy(true);
      try {
        const rr = await DCM.runAllowlistAdd(e.domain);
        toast(rr.errno === 0 ? 'Agregado a allowlist: ' + e.domain : backendError(rr, 'allowlist'), rr.errno === 0 ? 'ok' : 'error');
        await refreshAllowlist();
      } finally { setBusy(false); }
    });
    const cp = document.createElement('button');
    cp.textContent = 'Copiar';
    cp.addEventListener('click', async () => {
      try {
        if (navigator.clipboard && navigator.clipboard.writeText) { await navigator.clipboard.writeText(e.domain); toast('Dominio copiado.', 'ok'); }
        else { toast(e.domain, 'ok'); }
      } catch (_) { toast(e.domain, 'ok'); }
    });
    acts.appendChild(al); acts.appendChild(cp);
    row.appendChild(head); row.appendChild(meta); row.appendChild(acts);
    box.appendChild(row);
  });
}
function evSummary(n) {
  const el2 = $('evSummary'); if (!el2) return;
  el2.textContent = (typeof n === 'number') ? I18N.t('ev.count').replace('{n}', String(n)) : I18N.t('ev.tap');
}
async function evOpen() {
  if (EV.open) return;
  EV.open = true; EV.gen++; EV.shown = EV.page;
  const body = $('evBody'); if (body) body.hidden = false;
  const tg = $('evToggle'); if (tg) tg.setAttribute('aria-expanded', 'true');
  const ch = $('evChevron'); if (ch) ch.textContent = '\u25B2';
  setText('eventsList', I18N.t('common.loading'));
  await refreshEvents();                      // UNA sola consulta
}
function evClose() {
  EV.gen++; EV.open = false;                  // invalida respuestas en vuelo
  const body = $('evBody'); if (body) body.hidden = true;
  const list = $('eventsList'); if (list) list.textContent = '';   // desmonta filas del DOM
  const more = $('eventsMore'); if (more) more.textContent = '';
  const st = $('eventsStats'); if (st) st.textContent = '';
  const tg = $('evToggle'); if (tg) tg.setAttribute('aria-expanded', 'false');
  const ch = $('evChevron'); if (ch) ch.textContent = '\u25BC';
  evSummary();
}
function wireEventsToggle() {
  const tg = $('evToggle'); if (!tg || tg._wired) return;
  tg._wired = true;
  tg.addEventListener('click', () => { if (EV.open) evClose(); else evOpen(); });
}

function wireEvents() {
  wireEventsToggle();
  const rf = $('btnEventsRefresh');
  if (rf) rf.addEventListener('click', async () => {
    if (busy) return; setBusy(true);
    setText('eventsList', 'Cargando…');
    try { await refreshEvents(); } finally { setBusy(false); }
  });
  const filt = $('eventsFilter');
  if (filt) filt.addEventListener('input', () => { if (!busy) refreshEvents(); });
  const stats = $('btnEventsStats');
  if (stats) stats.addEventListener('click', async () => {
    if (busy) return; setBusy(true);
    try {
      const r = await DCM.run('eventsStats');
      const d = safeParse(r.stdout);
      if (d) {
        setText('eventsStats', 'Total ' + d.total + ' · malware ' + d.malware + ' · phishing ' + d.phishing +
          ' · estafas ' + d.scams + ' · rastreadores ' + d.trackers + ' · ads ' + d.ads +
          ' · cripto ' + d.cryptomining + ' · top: ' + (d.top_domain || '-') +
          ' · listas: ' + (d.lists_last_update || '-'));
      } else { setText('eventsStats', (r.stdout || r.stderr || '').trim()); }
    } finally { setBusy(false); }
  });
  const clr = $('btnEventsClear');
  if (clr) clr.addEventListener('click', async () => {
    if (busy) return;
    if (!confirm(SEC_STR.confirmEventsClear)) return;
    setBusy(true);
    try {
      const r = await DCM.run('eventsClear');
      toast(r.errno === 0 ? 'Historial borrado.' : backendError(r, 'events clear'), r.errno === 0 ? 'ok' : 'error');
      setText('eventsList', '(sin eventos)');
      setText('eventsStats', '');
    } finally { setBusy(false); }
  });
  const exp = $('btnEventsExport');
  if (exp) exp.addEventListener('click', async () => {
    if (busy) return; setBusy(true);
    try {
      const r = await DCM.run('eventsList');
      const d = safeParse(r.stdout);
      const text = d && d.events ? d.events.map((e) => [e.time, e.domain, e.category, e.rule].join('\t')).join('\n') : '';
      setText('eventsList', text || '(sin eventos)');
      toast('Eventos volcados abajo para copiar.', 'ok');
    } finally { setBusy(false); }
  });
}

/* ---------------------------- privacidad -------------------------------- */
function applyHistFromStatus(s) {
  if (!s) return;
  const hm = $('histModeSelect');
  if (hm && document.activeElement !== hm && s.hist_mode) hm.value = s.hist_mode;
  const hd = $('histDaysSelect');
  if (hd && document.activeElement !== hd && s.hist_days) hd.value = String(s.hist_days);
  const hx = $('histMaxInput');
  if (hx && document.activeElement !== hx && s.hist_max) hx.value = String(s.hist_max);
}
function wirePrivacy() {
  const btn = $('btnHistApply');
  if (!btn) return;
  btn.addEventListener('click', async () => {
    if (busy) return;
    setBusy(true);
    try {
      const mode = ($('histModeSelect') || {}).value || 'blocked';
      const days = ($('histDaysSelect') || {}).value || '3';
      let max = parseInt(($('histMaxInput') || {}).value, 10);
      if (!(max >= 50 && max <= 10000)) { toast('El maximo debe estar entre 50 y 10000.', 'error'); setBusy(false); return; }
      // Cada set-flag es una cadena FIJA (clave conocida + valor de lista blanca).
      const CLIcmd = DCM.cli();
      const seq = [
        CLIcmd + ' set-flag hist_mode ' + mode,
        CLIcmd + ' set-flag hist_days ' + days,
        CLIcmd + ' set-flag hist_max ' + max
      ];
      let okAll = true, lastErr = '';
      for (const cmd of seq) {
        const r = await execRawExternal(cmd);
        if (r.errno !== 0) { okAll = false; lastErr = backendError(r); break; }
      }
      toast(okAll ? 'Preferencias guardadas.' : lastErr, okAll ? 'ok' : 'error');
      await refreshStatus();
    } finally { setBusy(false); }
  });
}
/* Ejecuta una de las cadenas set-flag FIJAS de privacidad (clave y valor ya
 * restringidos a listas blancas de la UI; la CLI revalida ambos). */
function execRawExternal(cmd) {
  return new Promise((resolve) => {
    if (!DCM.available()) { resolve({ errno: -1, stdout: '', stderr: 'API ksu no disponible.' }); return; }
    const cb = '__dcm_hist_' + Date.now() + '_' + Math.random().toString(36).slice(2);
    let done = false;
    window[cb] = (errno, stdout, stderr) => {
      if (done) return; done = true;
      try { delete window[cb]; } catch (_) { window[cb] = undefined; }
      resolve({ errno: Number(errno), stdout: String(stdout || ''), stderr: String(stderr || '') });
    };
    setTimeout(() => { if (!done) { done = true; try { delete window[cb]; } catch (_) {} resolve({ errno: -1, stdout: '', stderr: 'Timeout.' }); } }, 30000);
    try { window.ksu.exec(cmd, JSON.stringify({}), cb); }
    catch (e) { if (!done) { done = true; resolve({ errno: -1, stdout: '', stderr: String(e) }); } }
  });
}

/* Extiende renderStatus para reflejar privacidad sin duplicar logica. */
const _origRenderStatus = renderStatus;
renderStatus = function (s) {
  _origRenderStatus(s);
  applyHistFromStatus(s);
};

/* Carga inicial de todas las secciones de seguridad. */
async function initSecurity() {
  wireProfiles();
  wireBlocklists();
  wireAllowlist();
  wireTempAllow();
  wireLeak();
  wireEvents();
  wirePrivacy();
  await refreshProtection();
  await refreshProfile();
  await refreshBlocklists();
  await refreshAllowlist();
  await refreshTempAllow();
  /* v1.0.0: los eventos NO se cargan en el arranque (panel lazy). */
}

/* ------------------------------------------------------------------------ */
/* ======================================================================== *
 *  RC2 — Catalogo, fuentes personalizadas, BindHosts, controles de servicio.
 *  Paginacion del lado cliente (no se renderizan miles de tarjetas de una).
 * ======================================================================== */
let catCache = [];        // metadata del catalogo; los DOM de listas se crean por acordeon
// Todos los encabezados visibles, filas desmontadas hasta abrir una categoría.
let catOpenGroup = '';
let catPageByGroup = Object.create(null);
let catLoaded = false;
let catLoading = null;
let catCliReady = false;
let catGroupCounts = Object.create(null);
let catGroupActive = Object.create(null);
const catLoadedGroups = new Set();
const catGroupLoading = Object.create(null);
const catSelection = new Set();
const catDisableSelection = new Set();
const CAT_PAGE_SIZE = 15;
const CAT_GROUP_DEFS = [
  { key: 'Security', label: 'Seguridad', description: 'Malware, phishing, estafas y otras amenazas.' },
  { key: 'Privacy', label: 'Privacidad', description: 'Rastreadores, telemetría, analítica y publicidad.' },
  { key: 'ParentalControl', label: 'Control parental', description: 'Fuentes agrupadas por Rethink para control familiar.' },
  { key: 'dcm', label: 'Fuentes propias de DNSCrypt Manager', description: 'Controles y listas mantenidas por este módulo.' },
  { key: 'rethink_unassigned', label: 'Sin grupo en el catálogo Rethink', description: 'Fuentes oficiales sin grupo declarado.' }
];

function catCategories(e) {
  return String(e.categories || '').split(',').map((c) => c.trim().toLowerCase()).filter(Boolean);
}
function catGroupKey(e) {
  if (e.source_name) return e.source_group || 'rethink_unassigned';
  return 'dcm';
}
function catPacks(e) {
  return String(e.source_packs || '').split('|').map((c) => c.trim()).filter(Boolean);
}
function catDisplayName(e) { return e.source_name || e.name; }
function catCanAdd(e) {
  return !e.enabled && !e.license_blocked && !e.activation_blocked && !e.archived &&
    e.upstream_status !== 'broken' && e.upstream_status !== 'archived';
}
function catStateLabel(e) {
  const failed = e.runtime_status === 'download_failed' || e.runtime_status === 'validation_failed';
  const hasCache = Number(e.cache_domains || 0) > 0;
  if (failed) return hasCache ? (e.enabled ? 'ACTIVA · error, usa caché' : 'ERROR · usa caché') : 'ERROR · sin caché';
  if (e.enabled) return 'ACTIVA';
  if (e.upstream_status === 'broken') return 'ROTA';
  if (e.archived || e.upstream_status === 'archived') return 'ARCHIVADA';
  if (e.license_blocked) return 'LICENSE_UNKNOWN';
  if (e.activation_blocked) return 'REQUIERE REVISIÓN';
  if (e.runtime_status === 'verified') return 'VERIFICADA';
  if (e.runtime_status === 'never_checked') return e.upstream_status === 'legacy' ? 'LEGACY' : 'SIN DESCARGAR';
  return e.runtime_status || e.upstream_status || 'sin verificar';
}

async function catLoad() {
  const r = await DCM.runCatalogGroupsJson();
  if (r.errno !== 0) { setText('catResults', backendError(r, 'catalog groups')); return false; }
  const d = safeParse(r.stdout);
  if (!d || !Array.isArray(d.groups)) { setText('catResults', 'Respuesta no valida del catalogo.'); return false; }
  catGroupCounts = Object.create(null);
  catGroupActive = Object.create(null);
  d.groups.forEach((g) => {
    if (!g || !g.key) return;
    const key = g.key === 'RethinkUnassigned' ? 'rethink_unassigned' : String(g.key);
    catGroupCounts[key] = Number(g.count || 0);
    catGroupActive[key] = Number(g.active || 0);
  });
  catLoaded = true;
  return true;
}

async function catLoadGroup(groupKey, force) {
  if (!force && catLoadedGroups.has(groupKey)) return true;
  if (!force && catGroupLoading[groupKey]) return catGroupLoading[groupKey];
  const backendKey = groupKey === 'rethink_unassigned' ? 'RethinkUnassigned' : groupKey;
  if (!DCM.runCatalogGroupJson) return false;
  const task = (async () => {
    const r = await DCM.runCatalogGroupJson(backendKey);
    if (r.errno !== 0) {
      setText('catResults', backendError(r, 'catalog list'));
      return false;
    }
    const d = safeParse(r.stdout);
    if (!d || !Array.isArray(d.entries)) {
      setText('catResults', 'Respuesta no valida del catalogo.');
      return false;
    }
    catCache = catCache.filter((e) => catGroupKey(e) !== groupKey).concat(d.entries);
    catLoadedGroups.add(groupKey);
    return true;
  })();
  catGroupLoading[groupKey] = task;
  try { return await task; }
  finally { delete catGroupLoading[groupKey]; }
}

async function catReload() {
  catCache = [];
  catLoadedGroups.clear();
  const ok = await catLoad();
  if (!ok) return false;
  if (catOpenGroup) await catLoadGroup(catOpenGroup);
  return true;
}

function catEnsureGroup(groupKey) {
  if (catLoadedGroups.has(groupKey) || catGroupLoading[groupKey]) return;
  catLoadGroup(groupKey).then((ok) => {
    if (ok) catRender();
  });
}

async function catLoadAllGroups() {
  for (const group of CAT_GROUP_DEFS) {
    if ((catGroupCounts[group.key] || 0) > 0) await catLoadGroup(group.key);
  }
  catRender();
}

function catFiltered() {
  const q = (($('catSearch') || {}).value || '').trim().toLowerCase();
  return catCache.filter((e) => {
    if (q) {
      const hay = [e.id, e.name, e.source_name, e.maintainer, e.source_subgroup,
        e.source_group, e.source_packs, e.source_formats, e.categories].join(' ').toLowerCase();
      if (hay.indexOf(q) < 0) return false;
    }
    return true;
  });
}

function catPendingCount() { return catSelection.size + catDisableSelection.size; }
function catEffectiveEnabled(e) {
  if (e.enabled) return !catDisableSelection.has(e.id);
  return catSelection.has(e.id);
}
function catStageGroup(groupKey, wantEnabled) {
  const entries = catCache.filter((e) => catGroupKey(e) === groupKey);
  entries.forEach((e) => {
    if (!e.enabled && !catCanAdd(e)) return;
    if (wantEnabled) {
      if (e.enabled) catDisableSelection.delete(e.id);
      else catSelection.add(e.id);
    } else {
      if (e.enabled) catDisableSelection.add(e.id);
      else catSelection.delete(e.id);
    }
  });
  catRender();
}
async function catToggleGroupSelection(groupKey, wantEnabled) {
  if (busy) return;
  if (!catLoadedGroups.has(groupKey)) {
    setText('catApplyStatus', 'Cargando las listas de esta categoría…');
    const ok = await catLoadGroup(groupKey);
    if (!ok) return;
  }
  catStageGroup(groupKey, wantEnabled);
}

function catRenderSelectionControls() {
  const n = catPendingCount();
  const add = $('btnCatAddSelected');
  const clear = $('btnCatClearSelection');
  if (add) {
    add.textContent = 'Aplicar cambios (' + n + ')';
    add.disabled = busy || n === 0;
  }
  if (clear) clear.disabled = busy || n === 0;
  setText('catSelectionStatus', n ? n + ' fuente(s) preparada(s). Se aplicarán al confirmar.' :
    'No hay fuentes seleccionadas. Marcar una casilla todavía no activa ni desactiva la lista.');
}

function catRenderPager(parent, group, list) {
  const pages = Math.max(1, Math.ceil(list.length / CAT_PAGE_SIZE));
  let page = Number(catPageByGroup[group] || 0);
  if (page >= pages) page = pages - 1;
  catPageByGroup[group] = page;
  if (pages < 2) return;
  const pager = document.createElement('div');
  pager.className = 'btn-row catalog-pager';
  const prev = document.createElement('button');
  prev.type = 'button'; prev.className = 'small'; prev.textContent = '‹'; prev.disabled = page === 0;
  prev.setAttribute('aria-label', 'Fuentes anteriores');
  prev.addEventListener('click', () => { catPageByGroup[group] = Math.max(0, page - 1); catRender(); });
  const status = document.createElement('span');
  status.className = 'hint'; status.textContent = (page + 1) + ' / ' + pages + ' · ' + list.length + ' fuentes';
  const next = document.createElement('button');
  next.type = 'button'; next.className = 'small'; next.textContent = '›'; next.disabled = page >= pages - 1;
  next.setAttribute('aria-label', 'Fuentes siguientes');
  next.addEventListener('click', () => { catPageByGroup[group] = Math.min(pages - 1, page + 1); catRender(); });
  pager.appendChild(prev); pager.appendChild(status); pager.appendChild(next); parent.appendChild(pager);
}

function catRenderSource(e) {
  const row = document.createElement('div');
  row.className = 'event-row catalog-source';
  const head = document.createElement('div');
  head.className = 'catalog-source-head';
  const title = document.createElement('span');
  title.className = 'catalog-source-title'; title.textContent = catDisplayName(e);
  const state = document.createElement('span');
  state.className = 'catalog-source-status'; state.textContent = catStateLabel(e);
  head.appendChild(title); head.appendChild(state);

  const pick = document.createElement('label');
  pick.className = 'catalog-source-pick';
  const check = document.createElement('input');
  check.type = 'checkbox'; check.checked = catEffectiveEnabled(e);
  check.disabled = busy || (!e.enabled && !catCanAdd(e));
  check.setAttribute('aria-label', (e.enabled ? 'Fuente activa ' : 'Seleccionar ') + catDisplayName(e));
  if (!check.disabled) {
    check.addEventListener('change', () => {
      if (busy) return;
      if (e.enabled) {
        if (check.checked) catDisableSelection.delete(e.id);
        else catDisableSelection.add(e.id);
      } else if (check.checked) catSelection.add(e.id);
      else catSelection.delete(e.id);
      catRender();
    });
  }
  pick.appendChild(check);
  const pickText = document.createElement('span');
  const pendingDisable = e.enabled && catDisableSelection.has(e.id);
  const pendingEnable = !e.enabled && catSelection.has(e.id);
  pickText.textContent = pendingDisable ? 'Se desactivará' : pendingEnable ? 'Se activará' :
    e.enabled ? 'Activa' : catCanAdd(e) ? 'Seleccionar' : 'No disponible';
  pick.appendChild(pickText); head.appendChild(pick); row.appendChild(head);

  const meta = document.createElement('div');
  meta.className = 'tl-sub catalog-source-meta';
  const packLabels = catPacks(e);
  const formats = String(e.source_formats || e.format || 'sin formato').replace(/\|/g, ', ');
  const project = e.source_subgroup || e.maintainer || 'Proyecto no especificado';
  const count = Number(e.cache_domains || e.valid_domains || 0);
  const countLabel = count > 0 ? count.toLocaleString() + ' dominios validados' : 'sin descargar';
  const successTime = Number(e.last_success || 0);
  const successLabel = successTime > 0 ? new Date(successTime * 1000).toLocaleString() : 'sin actualización';
  const labels = packLabels.length ? packLabels : catCategories(e);
  meta.textContent = project + (labels.length ? ' · ' + labels.join(' · ') : '') +
    ' · formato: ' + formats + ' · ' + countLabel + ' · última actualización: ' + successLabel +
    (e.recommended ? ' · recomendada' : '');
  row.appendChild(meta);

  const reasons = [];
  if (e.license_blocked) reasons.push('LICENSE_UNKNOWN: no se descarga ni activa hasta verificar la licencia del proyecto original.');
  if (e.activation_blocked) reasons.push('Requiere revisión técnica: combina varias URLs, usa un transporte no admitido o no tiene una conversión DNS segura.');
  if (e.upstream_status === 'broken') reasons.push('El catálogo upstream la marca retirada o no publica una URL utilizable.');
  else if (e.archived || e.upstream_status === 'archived') reasons.push('Fuente archivada.');
  else if (e.upstream_status === 'legacy') reasons.push('Fuente heredada; revisar vigencia antes de usarla.');
  if (reasons.length) {
    const note = document.createElement('div');
    note.className = 'hint catalog-source-unavailable'; note.textContent = reasons.join(' '); row.appendChild(note);
  }

  const urls = String(e.source_urls || '').split('|').filter(Boolean);
  if (urls.length) {
    const details = document.createElement('details');
    details.className = 'catalog-source-details';
    const summary = document.createElement('summary'); summary.textContent = 'Ver procedencia upstream';
    details.appendChild(summary);
    urls.forEach((url, index) => {
      const line = document.createElement('div'); line.className = 'catalog-source-url';
      if (/^https:\/\//i.test(url)) {
        const link = document.createElement('a'); link.href = url; link.target = '_blank';
        link.rel = 'noopener noreferrer'; link.textContent = 'Fuente ' + (index + 1) + ': ' + url;
        line.appendChild(link);
      } else {
        line.textContent = 'Fuente ' + (index + 1) + ': ' + url + ' (no se descarga sin HTTPS)';
      }
      details.appendChild(line);
    });
    row.appendChild(details);
  }

  return row;
}

function catRender() {
  const box = $('catResults');
  if (!box) return;
  catRenderSelectionControls();
  box.textContent = '';
  if (!catLoaded) { box.textContent = catCliReady ? 'Tocá una categoría para cargar las fuentes.' : 'El catálogo se carga al abrir esta sección.'; return; }
  const query = (($('catSearch') || {}).value || '').trim();
  CAT_GROUP_DEFS.forEach((group) => {
    const full = catCache.filter((e) => catGroupKey(e) === group.key);
    const knownCount = Number(catGroupCounts[group.key] || full.length || 0);
    if (!knownCount) return;
    const loaded = catLoadedGroups.has(group.key);
    const matches = loaded ? catFiltered().filter((e) => catGroupKey(e) === group.key) : [];
    if (query && loaded && !matches.length) return;
    const activeCount = catGroupActive[group.key] != null ? catGroupActive[group.key] : full.filter((e) => e.enabled).length;
    const section = document.createElement('section'); section.className = 'catalog-group';
    const header = document.createElement('div'); header.className = 'catalog-group-header';
    const toggle = document.createElement('button'); toggle.type = 'button';
    toggle.className = 'catalog-group-toggle';
    const expanded = catOpenGroup === group.key;
    toggle.setAttribute('aria-expanded', expanded ? 'true' : 'false');
    toggle.setAttribute('aria-controls', 'cat-panel-' + group.key);
    const label = document.createElement('span'); label.className = 'catalog-group-label'; label.textContent = group.label;
    const count = document.createElement('span'); count.className = 'catalog-group-count';
    count.textContent = (query && loaded ? matches.length + ' de ' : '') + knownCount + ' listas · ' + activeCount + ' activas';
    const master = document.createElement('label'); master.className = 'catalog-group-pick';
    const masterCheck = document.createElement('input'); masterCheck.type = 'checkbox';
    masterCheck.setAttribute('aria-label', 'Activar o desactivar todas las listas de ' + group.label);
    const actionable = loaded ? full.filter((e) => e.enabled || catCanAdd(e)) : [];
    const enabledNow = actionable.filter(catEffectiveEnabled).length;
    masterCheck.checked = actionable.length > 0 && enabledNow === actionable.length;
    masterCheck.indeterminate = loaded ? (enabledNow > 0 && enabledNow < actionable.length) : activeCount > 0;
    masterCheck.disabled = busy || (loaded && actionable.length === 0);
    masterCheck.addEventListener('click', (ev) => { if (ev && ev.stopPropagation) ev.stopPropagation(); });
    masterCheck.addEventListener('change', () => {
      if (busy) return;
      catToggleGroupSelection(group.key, masterCheck.checked);
    });
    const masterText = document.createElement('span'); masterText.textContent = 'Todas';
    master.appendChild(masterCheck); master.appendChild(masterText);
    const chevron = document.createElement('span'); chevron.className = 'catalog-group-chevron'; chevron.textContent = '›';
    // La casilla es HERMANA del botón: nunca un input interactivo dentro de
    // otro botón. Tocar "Todas" no debe cerrar/abrir el acordeón en Android.
    toggle.appendChild(label); toggle.appendChild(count); toggle.appendChild(chevron);
    toggle.addEventListener('click', () => {
      if (busy) return;
      catOpenGroup = catOpenGroup === group.key ? '' : group.key;
      catPageByGroup[group.key] = 0;
      catRender();
      if (catOpenGroup === group.key) catEnsureGroup(group.key);
    });
    header.appendChild(toggle); header.appendChild(master); section.appendChild(header);
    const panel = document.createElement('div'); panel.className = 'catalog-group-panel';
    panel.id = 'cat-panel-' + group.key; panel.hidden = !expanded;
    if (expanded) {
      if (!loaded) {
        const loading = document.createElement('div'); loading.className = 'hint';
        loading.textContent = 'Cargando fuentes de esta categoría…'; panel.appendChild(loading);
      } else if (!matches.length) {
        const empty = document.createElement('div'); empty.className = 'hint'; empty.textContent = 'No hay fuentes que coincidan en esta categoría.'; panel.appendChild(empty);
      } else {
        let page = Number(catPageByGroup[group.key] || 0);
        const pages = Math.max(1, Math.ceil(matches.length / CAT_PAGE_SIZE));
        if (page >= pages) page = pages - 1;
        catPageByGroup[group.key] = page;
        const slice = matches.slice(page * CAT_PAGE_SIZE, page * CAT_PAGE_SIZE + CAT_PAGE_SIZE);
        slice.forEach((e) => panel.appendChild(catRenderSource(e)));
        catRenderPager(panel, group.key, matches);
      }
    }
    section.appendChild(panel); box.appendChild(section);
  });
}

async function catRefreshAndRender() {
  if (!catCliReady) { catRender(); return false; }
  if (catLoading) return catLoading;
  setText('catResults', 'Cargando solo metadatos de las fuentes…');
  catLoading = (async () => {
    const ok = await catLoad();
    if (ok) {
      // Mostrar primero TODOS los encabezados, sin buscador ni filas montadas.
      catRender();
      if (catOpenGroup && (catGroupCounts[catOpenGroup] || 0) > 0) {
        await catLoadGroup(catOpenGroup);
        catRender();
      }
    }
    return ok;
  })();
  try { return await catLoading; } finally { catLoading = null; }
}

async function catApplySelected() {
  if (busy) return;
  const enableIds = Array.from(catSelection).filter((id) => {
    const e = catCache.find((item) => item.id === id);
    if (!e || !catCanAdd(e)) { catSelection.delete(id); return false; }
    return true;
  });
  const disableIds = Array.from(catDisableSelection).filter((id) => {
    const e = catCache.find((item) => item.id === id);
    if (!e || !e.enabled) { catDisableSelection.delete(id); return false; }
    return true;
  });
  const actions = enableIds.map((id) => ({ id, mode: 'enable' }))
    .concat(disableIds.map((id) => ({ id, mode: 'disable' })));
  if (!actions.length) { catRenderSelectionControls(); return; }
  const failures = [];
  let applied = 0;
  setBusy(true);
  document.querySelectorAll('#catResults input[type="checkbox"]').forEach((check) => { check.disabled = true; });
  try {
    for (let i = 0; i < actions.length; i++) {
      const action = actions[i];
      const e = catCache.find((item) => item.id === action.id);
      const verb = action.mode === 'enable' ? 'Activando' : 'Desactivando';
      setText('catApplyStatus', verb + ' ' + (i + 1) + ' de ' + actions.length + ': ' + (e ? catDisplayName(e) : action.id) + '…');
      try {
        const r = action.mode === 'enable' ? await DCM.runCatalogEnable(action.id) : await DCM.runCatalogDisable(action.id);
        if (r && r.errno === 0) {
          if (action.mode === 'enable') catSelection.delete(action.id);
          else catDisableSelection.delete(action.id);
          applied++;
        } else failures.push((e ? e.name : action.id) + ': ' + backendError(r, 'catalog'));
      } catch (err) {
        failures.push((e ? e.name : action.id) + ': ' + String(err && err.message || err));
      }
    }
    await catReload();
  } finally {
    setBusy(false);
    catRender();
  }
  const summary = applied + ' cambio(s) aplicado(s)' + (failures.length ? '; ' + failures.length + ' con error (siguen preparados).' : '.');
  setText('catApplyStatus', summary + (failures.length ? ' ' + failures.join(' · ') : ''));
  toast(summary, failures.length ? 'error' : 'ok');
}

function wireCatalog() {
  const s = $('catSearch');
  if (s) s.addEventListener('input', () => {
    catPageByGroup = Object.create(null);
    if (!catLoaded && catCliReady) { catRefreshAndRender(); return; }
    catRender();
    if (String(s.value || '').trim()) catLoadAllGroups();
  });
  const add = $('btnCatAddSelected');
  if (add) add.addEventListener('click', catApplySelected);
  const clear = $('btnCatClearSelection');
  if (clear) clear.addEventListener('click', () => { catSelection.clear(); catDisableSelection.clear(); catRender(); });
  const up = $('btnCatUpdate');
  if (up) up.addEventListener('click', async () => {
    if (busy) return; setBusy(true);
    setText('catResults', 'Actualizando fuentes activas (puede tardar)…');
    try {
      const r = await DCM.runCatalogUpdate();
      toast(r.errno === 0 ? 'Fuentes actualizadas.' : backendError(r, 'update'), r.errno === 0 ? 'ok' : 'error');
      if (await catReload()) catRender();
    } finally { setBusy(false); }
  });
  const cp = $('btnCatCompile');
  if (cp) cp.addEventListener('click', async () => {
    if (busy) return; setBusy(true);
    setText('catResults', 'Compilando…');
    try {
      const r = await DCM.runCatalogCompile();
      toast(r.errno === 0 ? 'Compilado.' : backendError(r, 'compile'), r.errno === 0 ? 'ok' : 'error');
      if (await catReload()) catRender();
    } finally { setBusy(false); }
  });
  const cf = $('btnCatConflicts');
  if (cf) cf.addEventListener('click', async () => {
    if (busy) return; setBusy(true);
    try {
      const r = await DCM.runCatalogConflicts();
      setText('catConflicts', (r.stdout || r.stderr || '').trim());
    } finally { setBusy(false); }
  });
}

async function customRender() {
  const box = $('customList');
  if (!box) return;
  if (!catLoaded) { await catLoad(); }
  if (!catLoadedGroups.has('dcm')) { await catLoadGroup('dcm'); }
  const customs = catCache.filter((e) => e.id.indexOf('custom_') === 0);
  box.textContent = '';
  if (!customs.length) { box.textContent = '(sin fuentes personalizadas)'; return; }
  customs.forEach((e) => {
    const row = document.createElement('div');
    row.className = 'event-row';
    const t = document.createElement('div');
    t.textContent = (e.enabled ? '● ' : '○ ') + e.name + ' [' + e.id + ']';
    const acts = document.createElement('div');
    acts.className = 'event-actions';
    const tog = document.createElement('button');
    tog.textContent = e.enabled ? 'Desactivar' : 'Activar';
    tog.addEventListener('click', async () => {
      if (busy) return; setBusy(true);
      try {
        const rr = e.enabled ? await DCM.runCatalogDisable(e.id) : await DCM.runCatalogEnable(e.id);
        toast(rr.errno === 0 ? 'Listo.' : backendError(rr, 'catalog'), rr.errno === 0 ? 'ok' : 'error');
        if (await catReload()) { await customRender(); catRender(); }
      } finally { setBusy(false); }
    });
    const del = document.createElement('button');
    del.textContent = 'Eliminar'; del.className = 'small danger';
    del.addEventListener('click', async () => {
      if (busy) return; setBusy(true);
      try {
        const rr = await DCM.runCustomRemove(e.id);
        toast(rr.errno === 0 ? 'Eliminada.' : backendError(rr, 'remove'), rr.errno === 0 ? 'ok' : 'error');
        if (await catReload()) { await customRender(); catRender(); }
      } finally { setBusy(false); }
    });
    acts.appendChild(tog); acts.appendChild(del);
    row.appendChild(t); row.appendChild(acts);
    box.appendChild(row);
  });
}
function wireCustom() {
  const add = $('btnCustomAdd');
  if (add) add.addEventListener('click', async () => {
    if (busy) return;
    const url = (($('customUrl') || {}).value || '').trim();
    const name = (($('customName') || {}).value || '').trim();
    if (!/^https:\/\//i.test(url)) { setText('customError', 'La URL debe empezar con https://'); return; }
    setText('customError', '');
    setBusy(true);
    try {
      const r = await DCM.runCustomAdd(url, name, '');
      toast(r.errno === 0 ? 'Fuente agregada (no activada).' : backendError(r, 'custom add'), r.errno === 0 ? 'ok' : 'error');
      if (r.errno === 0) { const u = $('customUrl'); if (u) u.value = ''; const n = $('customName'); if (n) n.value = ''; }
      if (await catReload()) { await customRender(); catRender(); }
    } finally { setBusy(false); }
  });
}

function wireBindhosts() {
  const an = $('btnBhAnalyze');
  if (an) an.addEventListener('click', async () => {
    if (busy) return;
    const dir = (($('bhDir') || {}).value || '').trim();
    if (!/^\//.test(dir)) { setText('bhError', 'Ingresa una ruta absoluta (empieza con /).'); return; }
    setText('bhError', '');
    setBusy(true);
    setText('bhResults', 'Analizando…');
    try {
      const r = await DCM.runBindhostsAnalyze(dir);
      setText('bhResults', (r.stdout || r.stderr || '').trim());
    } finally { setBusy(false); }
  });
  const im = $('btnBhImport');
  if (im) im.addEventListener('click', async () => {
    if (busy) return;
    const dir = (($('bhDir') || {}).value || '').trim();
    if (!/^\//.test(dir)) { setText('bhError', 'Ingresa una ruta absoluta.'); return; }
    if (!confirm('Importar desde ' + dir + '? Se agregaran dominios a blacklist/allowlist y se activaran fuentes reconocidas.')) return;
    setText('bhError', '');
    setBusy(true);
    setText('bhResults', 'Importando…');
    try {
      const r = await DCM.runBindhostsImport(dir);
      setText('bhResults', (r.stdout || r.stderr || '').trim());
      toast(r.errno === 0 ? 'Importado.' : backendError(r, 'import'), r.errno === 0 ? 'ok' : 'error');
      if (await catReload()) catRender();
    } finally { setBusy(false); }
  });
}

/* svcRender (motor heredado RC2 `service`) eliminado en v1.0.0: la tarjeta quedaba
   vacia y duplicaba "Privacidad por servicio" (backend real `service-control`). */

function initCatalogRC2() {
  wireCatalog();
  wireCustom();
  wireBindhosts();
}

function catOnRoute(route) {
  if (route !== 'lists' || !catCliReady || catLoaded) return;
  catRefreshAndRender().then(function (loaded) {
    if (loaded) customRender();
  });
}

/* Tarjeta de entorno (v0.3 A1): corre `environment status` y lo muestra. */
async function refreshEnvironmentCard() {
  const box = $('envCard');
  if (!box) return;
  if (!DCM.runEnvironmentStatus) { box.textContent = '-'; return; }
  box.textContent = (typeof I18N !== 'undefined' && I18N.t) ? I18N.t('common.loading') : 'Loading...';
  try {
    const r = await DCM.runEnvironmentStatus();
    const txt = (r && (r.stdout || r.stderr) ? (r.stdout || r.stderr) : '').trim();
    box.textContent = txt || (I18N && I18N.t ? I18N.t('env.cli.unresolved') : '-');
  } catch (_) {
    box.textContent = (I18N && I18N.t) ? I18N.t('common.error') : 'error';
  }
}
function wireEnvironment() {
  const b = $('btnEnvRefresh');
  if (b) b.addEventListener('click', function () { if (!busy) refreshEnvironmentCard(); });
}

/* A2.5: source doctor en la WebUI. DOM seguro (createElement/textContent),
   sin innerHTML con datos externos. Muestra estado humano, failure_class,
   ultima copia valida, HTTP, hostname + detalles y botones de accion. */
function renderSourceDoctor(container, d) {
  container.textContent = '';
  const t = (k) => (typeof I18N !== 'undefined' && I18N.t) ? I18N.t(k) : k;
  const fc = d.failure_class || 'sin_lista';
  const stateKey = DCM.failureClassToState(fc);
  // Badge de estado humano
  const badge = document.createElement('div');
  badge.className = 'src-badge src-' + stateKey;
  badge.textContent = t('src.state.' + stateKey) + '  ·  ' + fc;
  container.appendChild(badge);
  // Campos legibles
  const rows = [
    ['hostname', d.hostname], ['http_status', d.http_status],
    ['source_hostname_blocked', d.source_hostname_blocked],
    ['last_valid_available', d.last_valid_available],
    ['last_valid_domains', d.last_valid_domains],
    ['last_valid_timestamp', d.last_valid_timestamp],
    ['runtime_status', d.runtime_status], ['recommendation', d.recommendation]
  ];
  const dl = document.createElement('div'); dl.className = 'src-fields';
  rows.forEach(([k, v]) => {
    if (v === undefined || v === '') return;
    const r = document.createElement('div'); r.className = 'src-row';
    const kk = document.createElement('span'); kk.className = 'src-k'; kk.textContent = k;
    const vv = document.createElement('span'); vv.className = 'src-v'; vv.textContent = String(v);
    r.appendChild(kk); r.appendChild(vv); dl.appendChild(r);
  });
  container.appendChild(dl);
  // Si hubo última copia válida, mostrar cantidad + fecha de forma destacada.
  if (d.last_valid_available === 'yes') {
    const lv = document.createElement('div'); lv.className = 'src-lastvalid';
    lv.textContent = t('src.lastvalid')
      .replace('{count}', String(d.last_valid_domains || '?'))
      .replace('{date}', String(d.last_valid_timestamp || '?'));
    container.appendChild(lv);
  }
  // Detalles tecnicos expandibles (createElement, no innerHTML)
  const det = document.createElement('details'); det.className = 'src-details';
  const sum = document.createElement('summary'); sum.textContent = t('src.action.copydetails').replace('Copy', 'Details').replace('Copiar', 'Detalles');
  const pre = document.createElement('pre'); pre.style.whiteSpace = 'pre-wrap';
  pre.textContent = Object.keys(d).map((k) => k + '=' + d[k]).join('\n');
  det.appendChild(sum); det.appendChild(pre); container.appendChild(det);
  // Botones de accion
  const bar = document.createElement('div'); bar.className = 'src-actions';
  const mkBtn = (labelKey, fn) => {
    const b = document.createElement('button'); b.className = 'small'; b.textContent = t(labelKey);
    b.addEventListener('click', fn); return b;
  };
  const id = d.source_id || '';
  bar.appendChild(mkBtn('src.action.diagnose', function () { if (!busy) runSourceDoctorUI(id); }));
  bar.appendChild(mkBtn('src.action.retry', function () { if (!busy) runSourceDoctorUI(id); }));
  bar.appendChild(mkBtn('src.action.copydetails', function () {
    const txt = pre.textContent;
    try { if (navigator.clipboard) navigator.clipboard.writeText(txt); } catch (_) {}
    toast(t('src.action.copydetails'), 'ok');
  }));
  container.appendChild(bar);
}

async function runSourceDoctorUI(id) {
  const box = $('srcDoctorResult'); if (!box) return;
  const theId = id || (($('srcDoctorId') || {}).value || '').trim();
  if (!/^[a-zA-Z0-9_-]+$/.test(theId)) { toast((I18N && I18N.t) ? I18N.t('common.error') : 'error', 'error'); return; }
  box.textContent = (typeof I18N !== 'undefined' && I18N.t) ? I18N.t('common.loading') : 'Loading...';
  try {
    const r = await DCM.runSourceDoctor(theId);
    const d = DCM.parseDoctor((r && (r.stdout || r.stderr)) ? (r.stdout || r.stderr) : '');
    if (!d.source_id) d.source_id = theId;
    renderSourceDoctor(box, d);
  } catch (_) {
    box.textContent = (I18N && I18N.t) ? I18N.t('common.error') : 'error';
  }
}
function wireSourceDoctor() {
  const b = $('btnSrcDoctor');
  if (b) b.addEventListener('click', function () { if (!busy) runSourceDoctorUI(); });
}

function init() {
  // Navegacion (SPA) e idioma se inicializan SIEMPRE, haya o no puente ksu.
  if (typeof Router !== 'undefined' && Router.init) {
    try {
      Router.init({ onChange: function (route) {
        if (typeof V030 !== 'undefined' && V030.onRoute) { try { V030.onRoute(route); } catch (e) {} }
        catOnRoute(route);
      } });
    } catch (_) {}
  }
  if (typeof I18N !== 'undefined' && I18N.init) {
    try {
      I18N.init().then(function () {
        const sel = $('langSelect');
        if (sel) {
          sel.value = I18N.current();
          sel.addEventListener('change', function () {
            if (I18N.setLang) I18N.setLang(sel.value);
          });
        }
      });
    } catch (_) {}
  }
  if (!DCM.available()) {
    const b = $('ksuBanner');
    if (b) { b.textContent = STR.noKsu; b.classList.remove('hidden'); }
    // Sin puente ksu no hay backend: navegacion/idioma siguen, pero no hay polling.
    return;
  }
  // Cablear listeners (seguro aunque la CLI aun no este resuelta).
  wireServiceButtons();
  wireTestDns();
  wireProviders();
  wireRedirect();
  wirePrivateDns();
  wireLogs();
  wirePanic();
  initSecurity();
  initCatalogRC2();
  wireEnvironment();
  wireSourceDoctor();
  // Resolver la ruta de la CLI (3 rutas de allowlist) ANTES de emitir comandos.
  DCM.resolveCli().then(function (path) {
    if (!path) {
      // La CLI existe pero no es ejecutable desde el contexto WebUI: en KernelSU
      // Next suele ser Hybrid Mount apagado. Mensaje claro, no rc=127.
      const b = $('ksuBanner');
      const msg = (typeof I18N !== 'undefined' && I18N.t) ? I18N.t('env.cli.unresolved') : '';
      if (b) { b.textContent = msg || 'No se pudo acceder a la CLI del modulo. Si usas KernelSU Next, activa Hybrid Mount, reinicia y vuelve a abrir la interfaz.'; b.classList.remove('hidden'); }
      // Igual mostramos el estado del entorno si se puede (usa comando fijo, no la CLI resuelta).
      if (typeof refreshEnvironmentCard === 'function') { try { refreshEnvironmentCard(); } catch (_) {} }
      return;
    }
    if (typeof refreshEnvironmentCard === 'function') { try { refreshEnvironmentCard(); } catch (_) {} }
    catCliReady = true;
    if (typeof Router !== 'undefined' && Router.current && Router.current() === 'lists') catOnRoute('lists');
    startPolling();
  });
}

document.addEventListener('DOMContentLoaded', init);

/* V030 (service-controls + transportes, lazy) se movio a webroot/js/controls.js (global var V030). */
